//
//  UserDBManager+ArcheryTable.h
//  XZArcheryBook
//
//  Created by liwenxiang on 2017/7/6.
//  Copyright © 2017年 祥子. All rights reserved.
//

#import "UserDBManager.h"

@interface UserDBManager (ArcheryTable)

@end
