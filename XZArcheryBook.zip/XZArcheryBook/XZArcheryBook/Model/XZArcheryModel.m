//
//  XZArcheryModel.m
//  XZArcheryBook
//
//  Created by liwenxiang on 2017/7/6.
//  Copyright © 2017年 祥子. All rights reserved.
//

#import "XZArcheryModel.h"

@implementation XZArcheryModel

@end
