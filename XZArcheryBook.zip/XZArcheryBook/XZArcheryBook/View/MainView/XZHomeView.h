//
//  XZHomeView.h
//  XZArcheryBook
//
//  Created by liwenxiang on 2017/7/6.
//  Copyright © 2017年 祥子. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "XZArcheryModel.h"


@interface XZHomeView : UIView

/** 射箭数据model */
@property (nonatomic , strong) XZArcheryModel * archeryModel;


@end
