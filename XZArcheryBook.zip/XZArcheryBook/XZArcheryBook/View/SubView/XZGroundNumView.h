//
//  XZGroundNumView.h
//  XZArcheryBook
//
//  Created by liwenxiang on 2017/7/5.
//  Copyright © 2017年 祥子. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XZGroundNumView : UIView

@end
